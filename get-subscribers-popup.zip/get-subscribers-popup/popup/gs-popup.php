<?php
$gs_general_settings = get_option('gs_General_Settings', false);
$gs_sp_settings      = get_option('gs_SP_Settings', false);
$activatedRadioValue = $gs_general_settings['gs_activated_radio'];
$ok                  = 'true';
if ($activatedRadioValue == 'gs_EXP') {
    if (!isset($gs_sp_settings['gs_sp_html'])) {
        $ok = 'false';
    }
} else {
    if (!isset($gs_sp_settings['gs_sp_popuptitle_text'])) {
        $ok = 'false';
    }
}
if ($ok == 'true') {
?>
<div class="gs_modal" id="gs_modal">
<div class="gs_modal_contents" id="gs_modal_contents">
	<center id="gs_modal_contents_wrap">
	<div class="gs_modal_contents_wrap" id="gs_modal_contents_wrap">
    <?php
    if ($activatedRadioValue == 'gs_EXP') {
        if (isset($gs_sp_settings['gs_sp_bg_color'])) {
            $gs_sp_bg_color = sanitize_text_field($gs_sp_settings['gs_sp_bg_color']);
        } else {
            $gs_sp_bg_color = '000';
        }
        if (isset($gs_sp_settings['gs_sp_bg_transparent'])) {
            $gs_sp_bg_transparent = $gs_sp_settings['gs_sp_bg_transparent'];
        } else {
            $gs_sp_bg_transparent = "";
        }
        if (isset($gs_sp_settings['gs_sp_html']))
            $gs_sp_html = $gs_sp_settings['gs_sp_html'];
        else
            $gs_sp_html = 'Popup not configured!';
?>
        <div class="gs_modal_contents_inside" id="gs_modal_contents_inside" style="background-color:<?php if($gs_sp_bg_transparent == 'on'){ echo "transparent";}else { echo $gs_sp_bg_color;}
?>">
        <?php
        echo $gs_sp_html;
?>
        </div>
        <?php
    } else {
        if (isset($gs_sp_settings['gs_sp_bg_color'])) {
            $gs_sp_bg_color = sanitize_text_field($gs_sp_settings['gs_sp_bg_color']);
        } else {
            $gs_sp_bg_color = '000';
        }
        if (isset($gs_sp_settings['gs_sp_txt_color'])) {
            $gs_sp_txt_color = sanitize_text_field($gs_sp_settings['gs_sp_txt_color']);
        } else {
            $gs_sp_txt_color = "fff";
        }
        if (isset($gs_sp_settings['gs_sp_bg_transparent'])) {
            $gs_sp_bg_transparent = $gs_sp_settings['gs_sp_bg_transparent'];
        } else {
            $gs_sp_bg_transparent = "";
        }
?>
		<div class="gs_modal_contents_inside" id="gs_modal_contents_inside" style="background-color:<?php if($gs_sp_bg_transparent == 'on'){ echo "transparent";}else { echo $gs_sp_bg_color;}
?>">
			<div id="fb-root"></div>
			<script>(function(d, s, id) {
				var js, fjs = d.getElementsByTagName(s)[0];
				if (d.getElementById(id)) return;
				js = d.createElement(s); js.id = id;
				js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7";
				fjs.parentNode.insertBefore(js, fjs);
			}(document, 'script', 'facebook-jssdk'));</script>

			<script type="text/javascript">
			window.twttr=(function(d,s,id){var t,js,fjs=d.getElementsByTagName(s)[0];if(d.getElementById(id)){return}js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);return window.twttr||(t={_e:[],ready:function(f){t._e.push(f)}})}(document,"script","twitter-wjs"));
			</script><?php
        $linkToGPScript = 'https://apis.google.com/js/platform.js';
?><script type="text/javascript" src="<?php
        echo $linkToGPScript;
?>"></script><?php
        if (isset($gs_sp_settings['gs_sp_fblike_checkbox']))
            $gs_sp_fblike_checkbox_val = $gs_sp_settings['gs_sp_fblike_checkbox'];
        else
            $gs_sp_fblike_checkbox_val='';
        if (isset($gs_sp_settings['gs_sp_fbshare_checkbox']))
            $gs_sp_fbshare_checkbox_val = $gs_sp_settings['gs_sp_fbshare_checkbox'];
        else
            $gs_sp_fbshare_checkbox_val='';
        if (isset($gs_sp_settings['gs_sp_twitter_checkbox']))
            $gs_sp_twitter_checkbox_val = $gs_sp_settings['gs_sp_twitter_checkbox'];
        else
            $gs_sp_twitter_checkbox_val='';
        if (isset($gs_sp_settings['gs_sp_gplus_checkbox']))
            $gs_sp_gplus_checkbox_val = $gs_sp_settings['gs_sp_gplus_checkbox'];
        else
            $gs_sp_gplus_checkbox_val='';
        if (isset($gs_sp_settings['gs_which_fb_page_to_like']))
            $gs_which_fb_page_to_like_val = $gs_sp_settings['gs_which_fb_page_to_like'];
        else
            $gs_which_fb_page_to_like_val='';
        if (isset($gs_sp_settings['gs_sp_fbbusinesspage_text']))
            $gs_sp_fbbusinesspage_text_val = $gs_sp_settings['gs_sp_fbbusinesspage_text'];
        else
            $gs_sp_fbbusinesspage_text_val='';
        if (isset($gs_sp_settings['gs_sp_popuptitle_text']))
            $gs_sp_popuptitle_text_val = esc_html(sanitize_text_field($gs_sp_settings['gs_sp_popuptitle_text']));
        else
            $gs_sp_popuptitle_text_val = 'Popup not configured!';
        if (isset($gs_sp_settings['gs_sp_popuptext_text']))
            $gs_sp_popuptext_text_val = esc_html(sanitize_text_field($gs_sp_settings['gs_sp_popuptext_text']));
        else {
            $gs_sp_popuptext_text_val = 'Please configure popup with your settings <a id="gs_modal_text" href=' . get_admin_url() . 'admin.php?page=gs_admin_settings>here</a>!';
        }
        if (isset($gs_sp_settings['gs_sp_imageurl_text']))
            $gs_sp_imageurl_text_val = $gs_sp_settings['gs_sp_imageurl_text'];
        if (isset($gs_sp_settings['gs_sp_closetext_text']))
            $gs_sp_closetext_text_val = esc_html(sanitize_text_field($gs_sp_settings['gs_sp_closetext_text']));
        
        $linkToLike       = '';
        $gs_fs_linkToLike = '';
        if ($gs_which_fb_page_to_like_val == 'gs_sp_currentpagelike_checkbox') {
            $linkToLike       = site_url() . $_SERVER['REQUEST_URI'];
            $gs_fs_linkToLike = site_url();
        } else if ($gs_which_fb_page_to_like_val == 'gs_sp_fbbusinesslike_checkbox') {
            $linkToLike = $gs_sp_fbbusinesspage_text_val;
        }
?><div class="gs_modal_title" id='gs_modal_title' style='color:<?php
        echo $gs_sp_txt_color;
?>'><?php
        echo $gs_sp_popuptitle_text_val;
?></div>
			<div class="gs_modal_text" id='gs_modal_text' style='color:<?php
        echo $gs_sp_txt_color;
?>'><?php
        echo $gs_sp_popuptext_text_val;
?></div>
			<br/>
			<div class="gs_popup_image" id="gs_popup_image"><?php
        if ($gs_sp_imageurl_text_val != '') {
?><img id="gs_popup_image" src="<?php
            echo $gs_sp_imageurl_text_val;
?>"><?php
        }
?></div>
             <div id='gs_social_icons_table'>
				<center id='gs_social_icons_table'>
					<div class="gs_social_icons_table" id='gs_social_icons_table'>
						<div class="gs_social_icons_table_row" id="gs_social_icons_table_row">
							<div class="gs_social_icons_table_cell" id="gs_social_icons_table_cell">
								<div id="gs_social_icons_table_cell" class="gs_hidden_cell gs_cell_facebook" style="<?php
        if ($gs_sp_fblike_checkbox_val == 'on')
            echo 'display:block;';
?>">
									<div id="gs_social_icons_table_cell" class="fb-like" data-href="<?php
        echo $linkToLike;
?>" data-layout="box_count" data-action="like" data-show-faces="false" data-share="false"></div>
								</div>
							</div>
							<div class="gs_social_icons_table_cell" id="gs_social_icons_table_cell">
								<div id="gs_social_icons_table_cell" class="gs_hidden_cell" style="<?php
        if ($gs_sp_fbshare_checkbox_val == 'on')
            echo 'display:block;';
?>">
									<div id="gs_social_icons_table_cell" class="fb-share-button" data-href="<?php
        echo $gs_fs_linkToLike;
?>" data-layout="box_count"></div>
								</div>
							</div>
							<div class="gs_social_icons_table_cell" id="gs_social_icons_table_cell">
								<div id="gs_social_icons_table_cell" class="gs_hidden_cell" style="text-align: center;<?php
        if ($gs_sp_twitter_checkbox_val == 'on')
            echo 'display:block;';
?>">
									<a id="gs_social_icons_table_cell" class="twitter-share-button" data-count="vertical" href="<?php
        echo $linkToLike;
?>">Tweet</a>
									<div id="gs_social_icons_table_cell" style="clear:both"></div>
								</div>
							</div>
							<div class="gs_social_icons_table_cell" id="gs_social_icons_table_cell">
								<div id="gs_social_icons_table_cell" class="gs_hidden_cell" style="<?php
        if ($gs_sp_gplus_checkbox_val == 'on')
            echo 'display:block;';
?>">
									<div id="gs_social_icons_table_cell" class="g-plusone" data-size="tall"></div>
								</div>
							</div>
						</div>
					</div>
				</center>
			</div>
			<div id="gs_close_modal" class="gs_close_modal" style='color:<?php
        echo $gs_sp_txt_color;
?>'><?php
        echo $gs_sp_closetext_text_val;
?></div>
		</div>
    <?php
    }
?>
	</div>
	</center>
</div>
</div>
<?php
}
?>