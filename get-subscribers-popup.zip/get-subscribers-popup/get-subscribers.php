<?php
/**
Plugin Name: Get-Subscribers Popup
Plugin URI: https://codecanyon.net/item/get-subscribers-popup/18190162
Description: Get more subscribers for your web page with this plugin!
Author: kisded
Version: 1.2
Author URI: http://codecanyon.net/user/kisded/portfolio
 */

require "update-checker/plugin-update-checker.php";
$fwdu3dcarPUC = PucFactory::buildUpdateChecker(
	"https://rawgit.com/sfatfarma/popup/master/info.json",
	__FILE__,
	"get-subscribers-popup"
);
add_action('admin_menu', 'fwd_gs_register_my_custom_menu_page');
function fwd_gs_register_my_custom_menu_page()
{
    add_menu_page('Get-Subscribers Popup Plugin', 'Get-Subscribers Popup Plugin', 'manage_options', 'fwd_gs_admin_settings', 'fwd_gs_admin_settings', plugins_url('images/icon.png', __FILE__ ));
}
function fwd_gs_add_settings_link( $links ) {
    $settings_link = '<a href="admin.php?page=fwd_gs_admin_settings">' . __( 'Settings' ) . '</a>';
    array_push( $links, $settings_link );
  	return $links;
}
$plugin = plugin_basename( __FILE__ );
add_filter( "plugin_action_links_$plugin", 'fwd_gs_add_settings_link' );
add_action('wp_footer', 'fwd_gs_popup_footer_content');
add_action('wp_enqueue_scripts', 'fwd_gs_footer_load_files');
function fwd_gs_footer_load_files()
{
    wp_register_style('fwd_gs-popup-style', plugins_url('styles/gs-popup.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('fwd_gs-popup-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('fwd_gs-footer-scripts', plugins_url('popup/gs-footer-scripts.js', __FILE__), array(), '1.0.0', true);
}
?><?php
function fwd_gs_popup_footer_content()
{
    $gs_general_settings = get_option('gs_General_Settings', false);
    $gs_sp_settings      = get_option('gs_SP_Settings', false);
    require_once plugin_dir_path(__FILE__) . 'popup/gs-popup.php';
?><script type="text/javascript">
        var $gs_general_settings = JSON.parse('<?php
    echo json_encode($gs_general_settings);
?>');
        </script>
        <script>
        var gs_cookies = {
          getItem: function (sKey) {
            if (!sKey) { return null; }
            return decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*" + encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1")) || null;
          },
          setItem: function (sKey, sValue, vEnd, sPath, sDomain, bSecure) {
            if (!sKey || /^(?:expires|max\-age|path|domain|secure)$/i.test(sKey)) { return false; }
            var sExpires = "";
            if (vEnd) {
              switch (vEnd.constructor) {
                case Number:
                  sExpires = vEnd === Infinity ? "; expires=Fri, 31 Dec 9999 23:59:59 GMT" : "; max-age=" + vEnd;
                  break;
                case String:
                  sExpires = "; expires=" + vEnd;
                  break;
                case Date:
                  sExpires = "; expires=" + vEnd.toUTCString();
                  break;
              }
            }
            document.cookie = encodeURIComponent(sKey) + "=" + encodeURIComponent(sValue) + sExpires + (sDomain ? "; domain=" + sDomain : "") + (sPath ? "; path=" + sPath : "") + (bSecure ? "; secure" : "");
            return true;
          }
        };
        </script><?php
}
add_action('admin_enqueue_scripts', 'fwd_gs_admin_load_files');
function fwd_gs_admin_load_files()
{
    wp_enqueue_script('jquery');
    wp_register_style('fwd_gs-popup-style', plugins_url('styles/gs-popup.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('fwd_gs-popup-style');
    wp_enqueue_script('fwd_gs-angular', plugins_url('popup/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('fwd_gs-angular-sanitize', plugins_url('popup/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('fwd_gs-settings-app', plugins_url('popup/gs-angular.js', __FILE__), array(), '1.0.0', true);
}

add_action('admin_init', 'fwd_gs_register_mysettingsgs');
function fwd_gs_register_mysettingsgs()
{
    register_setting('gs_option_group', 'gs_General_Settings');
    register_setting('gs_option_group', 'gs_SP_Settings');
}

function fwd_gs_admin_settings()
{
?><div class="wrap gs_pops">
    <div>
        <form id="myForm" method="post" action="options.php"><?php
    settings_fields('gs_option_group');
?><?php
    do_settings_sections('gs_option_group');
?><?php
    $gs_general_settings = get_option('gs_General_Settings', false);
    if (isset($gs_general_settings['gs_activated_radio'])) {
        $activatedRadioValue = $gs_general_settings['gs_activated_radio'];
    } else {
        $activatedRadioValue = 'gs_NO';
    }
    if (isset($gs_general_settings['gs_use_cookies'])) {
        $gs_use_cookies = $gs_general_settings['gs_use_cookies'];
    } else {
        $gs_use_cookies = '';
    }
    if (isset($gs_general_settings['gs_show_method_desktop'])) {
        $gs_show_method_desktop = $gs_general_settings['gs_show_method_desktop'];
    } else {
        $gs_show_method_desktop = 'Leave intent';
    }
    if (isset($gs_general_settings['gs_show_method_mobile'])) {
        $gs_show_method_mobile = $gs_general_settings['gs_show_method_mobile'];
    } else {
        $gs_show_method_mobile = 'Page load';
    }
    if (isset($gs_general_settings['gs_main_background'])) {
        $gs_main_background = $gs_general_settings['gs_main_background'];
    } else {
        $gs_main_background = '';
    }
    if (isset($gs_general_settings['gs_main_page'])) {
        $gs_main_page = $gs_general_settings['gs_main_page'];
    } else {
        $gs_main_page = '';
    }
    if (!$activatedRadioValue) {
        $activatedRadioValue = "gs_YES";
    }
    
    $gs_sp_settings = get_option('gs_SP_Settings', false);
    if (isset($gs_sp_settings['gs_sp_fblike_checkbox'])) {
        $gs_sp_fblike_checkbox_val = $gs_sp_settings['gs_sp_fblike_checkbox'];
    } else {
        $gs_sp_fblike_checkbox_val = '';
    }
    if (isset($gs_sp_settings['gs_sp_fbshare_checkbox'])) {
        $gs_sp_fbshare_checkbox_val = $gs_sp_settings['gs_sp_fbshare_checkbox'];
    } else {
        $gs_sp_fbshare_checkbox_val = '';
    }
    if (isset($gs_sp_settings['gs_sp_twitter_checkbox'])) {
        $gs_sp_twitter_checkbox_val = $gs_sp_settings['gs_sp_twitter_checkbox'];
    } else {
        $gs_sp_twitter_checkbox_val = '';
    }
    if (isset($gs_sp_settings['gs_sp_gplus_checkbox'])) {
        $gs_sp_gplus_checkbox_val = $gs_sp_settings['gs_sp_gplus_checkbox'];
    } else {
        $gs_sp_gplus_checkbox_val = '';
    }
    if (isset($gs_sp_settings['gs_which_fb_page_to_like'])) {
        $gs_which_fb_page_to_like_val = $gs_sp_settings['gs_which_fb_page_to_like'];
    } else {
        $gs_which_fb_page_to_like_val = "gs_sp_currentpagelike_checkbox";
    }
    if (isset($gs_sp_settings['gs_sp_fbbusinesspage_text'])) {
        $gs_sp_fbbusinesspage_text_val = $gs_sp_settings['gs_sp_fbbusinesspage_text'];
    } else {
        $gs_sp_fbbusinesspage_text_val = 'Full Page Link';
    }
    if (isset($gs_sp_settings['gs_sp_popuptitle_text'])) {
        $gs_sp_popuptitle_text_val = esc_html(sanitize_text_field($gs_sp_settings['gs_sp_popuptitle_text']));
    } else {
        $gs_sp_popuptitle_text_val = "We beg you, STAY!";
    }
    if (isset($gs_sp_settings['gs_sp_html'])) {
        $gs_sp_html = $gs_sp_settings['gs_sp_html'];
    } else {
        $gs_sp_html = "";
    }
    if (isset($gs_sp_settings['gs_sp_popuptext_text'])) {
        $gs_sp_popuptext_text_val = esc_html(sanitize_text_field($gs_sp_settings['gs_sp_popuptext_text']));
    } else {
        $gs_sp_popuptext_text_val = "If you leave, a kitten in the world will die";
    }
    if (isset($gs_sp_settings['gs_sp_imageurl_text'])) {
        $gs_sp_imageurl_text_val = $gs_sp_settings['gs_sp_imageurl_text'];
    } else {
        $gs_sp_imageurl_text_val = "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRtpmFnMEy_KuZ_BCYDCieEIurWLrZmyYFcARXJURnjDbTgq60j";
    }
    if (isset($gs_sp_settings['gs_sp_closetext_text'])) {
        $gs_sp_closetext_text_val = esc_html(sanitize_text_field($gs_sp_settings['gs_sp_closetext_text']));
    } else {
        $gs_sp_closetext_text_val = "I have mercy of this little fellow";
    }
    if (isset($gs_sp_settings['gs_sp_bg_color'])) {
        $gs_sp_bg_color = sanitize_text_field($gs_sp_settings['gs_sp_bg_color']);
    } else {
        $gs_sp_bg_color = "#ffffff";
    }
    if (isset($gs_sp_settings['gs_sp_bg_transparent'])) {
        $gs_sp_bg_transparent = $gs_sp_settings['gs_sp_bg_transparent'];
    } else {
        $gs_sp_bg_transparent = "";
    }
    if (isset($gs_sp_settings['gs_sp_txt_color'])) {
        $gs_sp_txt_color = sanitize_text_field($gs_sp_settings['gs_sp_txt_color']);
    } else {
        $gs_sp_txt_color = "#000000";
    }
?><script>
                var gs_assets = {
                    icons:{
                        fblike: "<?php
    echo plugins_url('images/social_icons/icon-fb-like.jpg', __FILE__);
?>",
                        fbshare: "<?php
    echo plugins_url('images/social_icons/icon-fb-share.jpg', __FILE__);
?>",
                        twitter: "<?php
    echo plugins_url('images/social_icons/icon-tweet.jpg', __FILE__);
?>",
                        gplus: "<?php
    echo plugins_url('images/social_icons/icon-plus.jpg', __FILE__);
?>"
                    }
                }
                var gs_admin_json = {
                        
                    popupenabled: '<?php
    echo $activatedRadioValue;
?>', 
                    social:{
                        html: '<?php
    $str = addslashes($gs_sp_html);
    $str = str_replace('/', '\/', $str);
    $str = str_replace(PHP_EOL, '', $str);
    $str = trim(preg_replace('/\s+/', ' ', $str));
    echo $str;
?>',
                        title: '<?php
    echo $gs_sp_popuptitle_text_val;
?>',
                        text: '<?php
    echo $gs_sp_popuptext_text_val;
?>',
                        showlike: ('<?php
    echo $gs_sp_fblike_checkbox_val;
?>' == 'on'),
                        showshare: ('<?php
    echo $gs_sp_fbshare_checkbox_val;
?>'== 'on'),
                        showtwitter: ('<?php
    echo $gs_sp_twitter_checkbox_val;
?>'== 'on'),
                        showgplus: ('<?php
    echo $gs_sp_gplus_checkbox_val;
?>'== 'on'),
                        fbpagetype: '<?php
    echo $gs_which_fb_page_to_like_val;
?>',
                        fbpageurl: '<?php
    echo $gs_sp_fbbusinesspage_text_val;
?>',                            
                        imageurl: '<?php
    echo $gs_sp_imageurl_text_val;
?>',
                        closetext: '<?php
    echo $gs_sp_closetext_text_val;
?>',
                        bgcolor: '<?php
    echo $gs_sp_bg_color;
?>',
                        transparent: '<?php
    echo $gs_sp_bg_transparent;
?>',
                        txtcolor: '<?php
    echo $gs_sp_txt_color;
?>',
                        gs_show_method_desktop: '<?php
    echo $gs_show_method_desktop;
?>',
                        gs_show_method_mobile: '<?php
    echo $gs_show_method_mobile;
?>'
                    }
                }
            </script>
            <div ng-app="gssettingsApp" ng-controller="gssettingsController" ng-cloak ng-init="initialized()">
                <div>
                    <div>
                        <span class="gs-sub-heading"><b>Get-Subscribers Popup:</b>&nbsp;&nbsp;&nbsp;</span>
                        
                        <label><input type="radio" name="gs_General_Settings[gs_activated_radio]" value="gs_YES"
                            id="radio_gs_yes" ng-model="settings.popupenabled"> Basic Settings</label>&nbsp; 
                        <label><input type="radio" name="gs_General_Settings[gs_activated_radio]" value="gs_EXP"
                            id="radio_gs_exp" ng-model="settings.popupenabled"> Your HTML Code</label>&nbsp; 
                        <label><input type="radio" name="gs_General_Settings[gs_activated_radio]" value="gs_NO" 
                            id="radio_gs_no" ng-model="settings.popupenabled"> Disable Popup</label>
                        <hr/>
                    </div>
                </div>
                <script type="text/javascript">
                    window.onload = function() {
                        var ex1 = document.getElementById('radio_gs_yes');
                        var ex2 = document.getElementById('radio_gs_exp');
                        var ex3 = document.getElementById('radio_gs_no');
                        ex1.onclick = handlerYES;
                        ex2.onclick = handlerEXP;
                        ex3.onclick = handlerNO;
                    }
                    function handlerYES() 
                    {
                        jQuery("#myForm").submit();
                    }

                    function handlerEXP() 
                    {  
                        jQuery("#myForm").submit();
                    }
                    function handlerNO() 
                    { 
                        jQuery("#myForm").submit();
                    }
                </script>
                <div class="gs_admin_main_table"><?php
    if ($activatedRadioValue == 'gs_YES') {
?><div class="gs_popuptype_holder"><div class="gs_pp_holder_left">
                        <div class="gs_radio_related_div" >
                            <div class="gs_radio_related_table"> 
                                <div class="gs_radio_related_row">
                                    <div class="gs_radio_related_cell">
                                        <div>
                                            <b>Your Popup Title:</b>
                                        </div>
                                        <input type="text" name="gs_SP_Settings[gs_sp_popuptitle_text]" ng-model="settings.social.title" size="68">
                                    </div>
                                </div>
                                <div class="gs_radio_related_row">
                                    <div class="gs_radio_related_cell">
                                        <div>
                                            <b>Your Popup Text:</b>
                                        </div>
                                        <input type="text" name="gs_SP_Settings[gs_sp_popuptext_text]" ng-model="settings.social.text" size="68">
                                    </div>
                                </div>
                                <div class="gs_radio_related_row">
                                    <div class="gs_radio_related_cell">
                                        <div>
                                            <b>Your Image URL:</b>
                                        </div>
                                        <input type="text" name="gs_SP_Settings[gs_sp_imageurl_text]" ng-model="settings.social.imageurl"
                                            ng-blur="imageSelected(settings.social.imageurl, 'social')" value="https://placeholdit.imgix.net/~text?txtsize=56&txt=600%C3%97250&w=600&h=250" size="68">
                                    </div>
                                </div>
                                <div class="gs_radio_related_row">
                                    <div class="gs_radio_related_cell">
                                        <div>
                                            <b>Add these Social Buttons:</b>
                                        </div>
                                        <div>
                                            <input type="checkbox" name="gs_SP_Settings[gs_sp_fblike_checkbox]" ng-model="settings.social.showlike">
                                            Facebook like&nbsp;
                                            <input type="checkbox" name="gs_SP_Settings[gs_sp_fbshare_checkbox]" ng-model="settings.social.showshare">
                                            Facebook share&nbsp;
                                            <input type="checkbox" name="gs_SP_Settings[gs_sp_twitter_checkbox]" ng-model="settings.social.showtwitter">
                                            Tweet&nbsp;
                                            <input type="checkbox" name="gs_SP_Settings[gs_sp_gplus_checkbox]"  ng-model="settings.social.showgplus">
                                            Google plus
                                        </div>
                                        <div ng-show="settings.social.showlike">
                                            <div style="border:1px solid #ccc; padding: 5px; margin-top: 10px;">
                                                <div>
                                                    <span>
                                                    <input type="radio" ng-model="settings.social.fbpagetype" value="gs_sp_currentpagelike_checkbox"
                                                        name="gs_SP_Settings[gs_which_fb_page_to_like]"> 
                                                    <label for="gs_sp_currentpagelike_checkbox">Get a like on visitor's current page</label>
                                                    </span>&nbsp;&nbsp;
                                                    <span>
                                                    <input type="radio" ng-model="settings.social.fbpagetype" value="gs_sp_fbbusinesslike_checkbox"
                                                        name="gs_SP_Settings[gs_which_fb_page_to_like]"> 
                                                    <label for="gs_sp_fbbusinesslike_checkbox">Get a like on Facebook business page</label>
                                                    </span>
                                                </div>
                                                <div style="margin-top:10px; margin-left:10px;" ng-show="settings.social.fbpagetype == 'gs_sp_fbbusinesslike_checkbox'">
                                                    <div>Link to your Facebook Business Page:</div>
                                                    <div><input type="text" name="gs_SP_Settings[gs_sp_fbbusinesspage_text]" ng-model="settings.social.fbpageurl"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="gs_radio_related_row">
                                    <div class="gs_radio_related_cell">
                                        <div>
                                            <b>Your Close Popup Text:</b>
                                        </div>
                                        <input type="text" name="gs_SP_Settings[gs_sp_closetext_text]" ng-model="settings.social.closetext" size="68">
                                    </div>
                                </div>
                                <div class="gs_radio_related_row">
                                    <div class="gs_radio_related_cell">
                                        <b>Text color:</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <input type="color" name="gs_SP_Settings[gs_sp_txt_color]" ng-model="settings.social.txtcolor">
                                    </div>
                                </div>
                                <div class="gs_radio_related_row">
                                    <div class="gs_radio_related_cell">
                                        <b>Background color:</b>
                                        <input type="color" name="gs_SP_Settings[gs_sp_bg_color]" ng-model="settings.social.bgcolor">
                                    </div>
                                </div>
                                <div class="gs_radio_related_row">
                                    <div class="gs_radio_related_cell">
                                        <b>Background transparent:</b>
                                        <input type="checkbox" id="gs_sp_bg_transparent" name="gs_SP_Settings[gs_sp_bg_transparent]"<?php
                if ($gs_sp_bg_transparent == 'on')
                    echo ' checked ';
        ?>>
                                    </div>
                                </div>
                                </br>
                                <div class="gs_border">
                                    <span class="gs-sub-heading"><b>Popup Visibility:</b></span><br/>
                                    <input type="checkbox" id="gs_use_cookies" name="gs_General_Settings[gs_use_cookies]"<?php
        if ($gs_use_cookies == 'on')
            echo ' checked ';
?>>
                                    Show popup once per visitor (uses cookies)
                                    &nbsp;&nbsp;&nbsp;<input type="checkbox" id="gs_main_page" name="gs_General_Settings[gs_main_page]"<?php
        if ($gs_main_page == 'on')
            echo ' checked ';
?>>
                                    Show only on main page&nbsp;
                                </div>
                                <div>
                                <b>When to show popup?</b></br>Desktop:
                        <select id="gs_show_method_desktop"  name="gs_General_Settings[gs_show_method_desktop]" ng-model="settings.social.gs_show_method_desktop">
                        <option ng-repeat="x in dnames">{{x}}</option>
                        </select></br>
                        Mobile:&nbsp;&nbsp;
                        <select id="gs_show_method_mobile"  name="gs_General_Settings[gs_show_method_mobile]" ng-model="settings.social.gs_show_method_mobile">
                        <option ng-repeat="x in mnames">{{x}}</option>
                        </select>
                        </div>
                        Click on the background does not close popup
                            &nbsp;&nbsp;&nbsp;<input type="checkbox" id="gs_main_background" name="gs_General_Settings[gs_main_background]"<?php
            if ($gs_main_background == 'on')
                echo ' checked ';
?>>
                            </div>
                        </div>
                    </div>
                    <div class="gs_pp_holder_right">
                        <center>
                            <div class="gs_pp_preview_wrapper gs_pp_preview_social" id="gs_pp_preview_social" style="background-color:<?php if($gs_sp_bg_transparent == 'on'){
?>
                                transparent
<?php
                                }else {
?>
                                {{settings.social.bgcolor}} 
<?php
}
?>
">
                                <div class="gs_pp_contents">
                                    <div class="gs_modal_title" style="color: {{settings.social.txtcolor}}">{{settings.social.title}}</div>
                                    <div class="gs_modal_text" style="color: {{settings.social.txtcolor}}">{{settings.social.text}}</div>
                                    <div class="gs_popup_image_try"><img ng-src="{{settings.social.imageurl}}" ng-show="settings.social.imageurl.trim().length > 0"></div>
                                    <div>
                                        <center>
                                            <table border="0">
                                                <tr>
                                                    <td><img ng-src="{{assets.icons.fblike}}" ng-show="settings.social.showlike" width="60" height="50"></td>
                                                    <td><img ng-src="{{assets.icons.fbshare}}" ng-show="settings.social.showshare" width="60" height="50"></td>
                                                    <td><img ng-src="{{assets.icons.twitter}}" ng-show="settings.social.showtwitter" width="60" height="50"></td>
                                                    <td><img ng-src="{{assets.icons.gplus}}" ng-show="settings.social.showgplus" width="60" height="50"></td>
                                                </tr>
                                            </table>
                                        </center>
                                    </div>
                                    <div class="gs_close_modal" style="color: {{settings.social.txtcolor}}">{{settings.social.closetext}}</div>
                                </div>
                            </div>
                        </center>
                    </div></div><?php
    } else {
        if ($activatedRadioValue == 'gs_EXP') {
?><div class="gs_popuptype_holder">
                        <div class="gs_pp_holder_left">
                        <div class="gs_radio_related_div" >
                            <div class="gs_radio_related_table"> 
                        <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <div>
                                    <b>HTML Code</b> (to add closing link, add id gs_close_me to html element):
                                </div>
                                <textarea name="gs_SP_Settings[gs_sp_html]" ng-model="settings.social.html" placeholder="Your HTML code here. If you need guidance with this, check help.html from provided zip file!" cols="68" rows="15"></textarea>
                            </div>
                        </div>
                        <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <b>Background color:</b>
                                <input type="color" name="gs_SP_Settings[gs_sp_bg_color]" ng-model="settings.social.bgcolor">
                            </div>
                        </div>
                        <div class="gs_radio_related_row">
                            <div class="gs_radio_related_cell">
                                <b>Background transparent:</b>
                                <input type="checkbox" id="gs_sp_bg_transparent" name="gs_SP_Settings[gs_sp_bg_transparent]"<?php
        if ($gs_sp_bg_transparent == 'on')
            echo ' checked ';
?>>
                            </div>
                        </div>
                        </br>
                        <div class="gs_border">
                            <span class="gs-sub-heading"><b>Popup Visibility:</b></span><br/>
                            <input type="checkbox" id="gs_use_cookies" name="gs_General_Settings[gs_use_cookies]"<?php
            if ($gs_use_cookies == 'on')
                echo ' checked ';
?>>
                            Show popup once per visitor (uses cookies)
                            &nbsp;&nbsp;&nbsp;<input type="checkbox" id="gs_main_page" name="gs_General_Settings[gs_main_page]"<?php
            if ($gs_main_page == 'on')
                echo ' checked ';
?>>
                            Show only on main page&nbsp;
                        </div>
                        <div>
                        <b>When to show popup?</b></br>Desktop:
                        <select id="gs_show_method_desktop"  name="gs_General_Settings[gs_show_method_desktop]" ng-model="settings.social.gs_show_method_desktop">
                        <option ng-repeat="x in dnames">{{x}}</option>
                        </select></br>
                        Mobile:&nbsp;&nbsp;
                        <select id="gs_show_method_mobile"  name="gs_General_Settings[gs_show_method_mobile]" ng-model="settings.social.gs_show_method_mobile" >
                        <option ng-repeat="x in mnames">{{x}}</option>
                        </select>
                        </div>
                        Click on the background does not close popup
                            &nbsp;&nbsp;&nbsp;<input type="checkbox" id="gs_main_background" name="gs_General_Settings[gs_main_background]"<?php
            if ($gs_main_background == 'on')
                echo ' checked ';
?>>
                        </div></div></div>
                        <div class="gs_pp_holder_right">
                            <center>
                                <div class="gs_pp_preview_wrapper gs_pp_preview_social" id="gs_pp_preview_social" style="background-color:<?php if($gs_sp_bg_transparent == 'on'){
?>
                                transparent
<?php
                                }else {
?>
                                {{settings.social.bgcolor}} 
<?php
}
?>
">
                                    <div class="gs_pp_contents">
                                        <div class="gs_modal">
                                            <div ng-bind-html="stripslashes(settings.social.html)"></div>
                                            </div>
                                    </div>
                                </div>
                            </center>
                        </div></div>
                        <?php
        }
    }
?></div>
            </div>
        </div>
    </div>
    <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save"/></p></div>
    </form>
    <div class="clear"></div>
</div>
<div class="clear"></div>
</div><?php
}
?>