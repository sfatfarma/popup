angular.module('gssettingsApp', ['ngSanitize'])
.controller('gssettingsController', function($scope, $sce) {
    $scope.settings = gs_admin_json;
    $scope.assets = gs_assets;
    $scope.reload = function()
    {
       location.reload(); 
    }
    $scope.stripslashes = function($str)
    {
        $str = $str.replace(/\\/g, '')
        $str = $sce.trustAsHtml($str);
        return $str;
    }
    $scope.dnames = ["Leave intent", "Page load", "Page load with 3 sec delay", "Page scroll"];
    $scope.mnames = ["Page load", "Page load with 3 sec delay", "Page scroll"];
});